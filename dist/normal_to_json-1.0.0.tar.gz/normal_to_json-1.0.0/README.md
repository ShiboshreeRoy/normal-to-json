# Normal to JSON Library

A simple Python library to convert normal data (e.g., dictionaries, lists, custom objects) into JSON format.

## Installation

```bash
pip install normal_to_json